import {Link} from 'react-router-dom'

function Movimentacao(){
  return (
    <div>
       <h1> MOVIMENTAÇÃO DA CONTA CORRENTE </h1> 
       <Link to = '/' > Voltar HOME</Link><br/>
     </div>
  )

}

export default Movimentacao;