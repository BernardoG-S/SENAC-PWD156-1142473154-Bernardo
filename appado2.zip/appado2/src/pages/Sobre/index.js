import {Link} from 'react-router-dom'

function Sobre(){
  return (
    <div>
       <h1> SOBRE NÓS </h1> 
       <Link to = '/' > Voltar HOME</Link><br/>
    </div>
  )

}

export default Sobre;