import {Link} from 'react-router-dom'

function Cadastro(){
  return (
    <div>
       <h1> CADASTRO </h1> 
       <Link to = '/' > Voltar HOME</Link><br/>
    </div>
  )

}

export default Cadastro;