import {Link} from 'react-router-dom'

function Movimentacao(){
  return (
    <div>
       <h1> SIMULAÇÃO DE FINANCIAMENTO </h1> 
       <Link to = '/' > Voltar HOME</Link><br/>
    </div>
  )

}

export default Movimentacao;